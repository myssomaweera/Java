import java.util.Scanner;
public class Q4 {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number");
        int num = input.nextInt();
        if (num%5 ==0){
            System.out.println("This number is a multiplication of 5");
        }else{
            System.out.println("This number is not a multiplication of 5");
        }
    }
}

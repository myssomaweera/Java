import java.util.Scanner;
public class Q3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a number:- ");
        int num = input.nextInt();

        if(num%2 == 0){
            System.out.println("The number "+num+" is divisible by 2");
        }else if(num%7 == 0){
            System.out.println("The number "+num+" is divisible by 7");
        }else if (num%2 == 0 && num%7 == 0){
            System.out.println("The number "+num+" is  divisible by both 2 & 7");
        }else{
            System.out.println("The number "+num+" is not divisible by 2 or 7");
        }
    }

    
}

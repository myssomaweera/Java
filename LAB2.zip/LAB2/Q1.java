import java.util.Scanner;

public class Q1{
    public static void main(String[] args) {
        int total = 0;
        double avg = 0.0; 
        Scanner input = new Scanner(System.in);
        for(int i=0;i<=4;i++){
            System.out.println("Please enter your marks:- ");
            int mark = input.nextInt();

            if (mark >= 80){
                System.out.println("Grade : A");
            }else if (mark >= 65) {
                System.out.println("Grade: B");
            } else if(mark >= 50) {
                System.out.println("Grade: C");
            }else{
                System.out.println("Grade: F");
            }
             total = total + mark;
        }
        System.out.println("The total marks are :- "+total);
        avg = total/4;
        System.out.println("The average of the marks are :- "+avg);

        input.close();
    }

}
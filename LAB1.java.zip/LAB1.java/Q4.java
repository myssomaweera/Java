public class Q4 {
    public static void main(String[] args){
        int num1 = 10;
        int num2 = 2;

        int add = num1 +  num2;
        int subtract = num1 - num2;
        int multiply = num1 * num2;
        int divide = num1 / num2;

        System.out.println("Addition: " + add);
        System.out.println("Subtraction: " + subtract); 
        System.out.println("Multiplication: " + multiply);
        System.out.println("Division: " + divide);
    }
}

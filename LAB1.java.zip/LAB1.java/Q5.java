import java.util.Scanner;

public class Q5 {
    public static void main(String[] args){
      Scanner input = new Scanner(System.in); 
      System.out.print("Enter your name: ");
      String name = input.nextLine();
      System.out.print("Enter your age: ");
      int age = input.nextInt();
      System.out.println("Name: " + name);
      System.out.println("Age: " + age);

      if (age >= 18){
        System.out.println("Your are an adult.");
      }else{
        System.out.println("You are a teenager.");
      }
    }
}

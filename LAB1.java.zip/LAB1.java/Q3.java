public class Q3 {
    public static void main(String[] args){
        System.out.println("Name - Yuhansa Somaweera");
        System.out.println("Degree - Cybersecurity VU");
    }
}
